package cubeselector

const (
	Random   = "random"
	Specific = "specific"
)

type CubeSelectionType string
