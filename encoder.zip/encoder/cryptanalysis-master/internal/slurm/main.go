package slurm

type Job struct {
	Id int
}
