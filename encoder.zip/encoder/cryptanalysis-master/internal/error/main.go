package error

import "errors"

var (
	ErrKeyNotFound = errors.New("key not found")
)
