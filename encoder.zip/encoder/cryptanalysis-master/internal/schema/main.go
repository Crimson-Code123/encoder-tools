package schema

import "cryptanalysis/internal/pipeline"

type Schema struct {
	Pipeline []pipeline.Pipe
}
