package encoding

type EncodingInfo struct {
	FreeVariables int
	Clauses       int
}
