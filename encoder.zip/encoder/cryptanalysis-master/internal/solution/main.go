package solution

type Range struct {
	Start int
	End   int
}
