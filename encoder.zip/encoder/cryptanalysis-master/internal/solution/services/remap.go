package services

func (solutionSvc *SolutionService) Remap(solutionPath string, varMapPath string) error {
	// info, err := solutionSvc.encoderSvc.ProcessInstanceName(solutionPath)
	// if err != nil {
	// 	return err
	// }
	// steps := info.Steps

	// // * 1. Read the reconstruction stack file and determine the literals that need to be preserved
	// varMapFile, err := os.OpenFile(varMapPath, os.O_RDONLY, 0600)
	// if err != nil {
	// 	return err
	// }
	// defer varMapFile.Close()

	// replacements := make(map[int]bool)
	// scanner := bufio.NewScanner(varMapFile)

	// TODO: Implement remapping and verification
	return nil
}
