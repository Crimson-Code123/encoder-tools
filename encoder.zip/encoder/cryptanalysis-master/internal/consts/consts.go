package consts

const (
	General = "general"
	Slurm   = "slurm"
)

const (
	Debug = "debug"
	Info  = "info"
)
