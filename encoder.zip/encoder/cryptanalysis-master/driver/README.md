This tool is written to drive scripts concurrently. As of now, the features
include parsing solver log files.

The scripts are embedded inside this tool, which means that the script files
will be written on the spot.