package main

import (
	"cryptanalysis/cmd"
)

func main() {
	cmd.Execute()
}
