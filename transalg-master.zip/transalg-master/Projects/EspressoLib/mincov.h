/* exported */
extern sm_row *sm_minimum_cover(sm_matrix *A, int *weight, int heuristic, int debug_level);
